# assignment2021scala - Main 5

* deadline: 21 January, 5pm
* [coursework description](https://nms.kcl.ac.uk/christian.urban/main_cw05.pdf)
* reference jar:
    [bf.jar](https://nms.kcl.ac.uk/christian.urban/bf.jar),
    [bfc.jar](https://nms.kcl.ac.uk/christian.urban/bfc.jar)
    